# IdCards > 2024-11-18 6:16pm
https://universe.roboflow.com/office-yq6ex/idcards-oysbj

Provided by a Roboflow user
License: CC BY 4.0

